To build the example application set JAVA_HOME and ANT_HOME environment variables.
